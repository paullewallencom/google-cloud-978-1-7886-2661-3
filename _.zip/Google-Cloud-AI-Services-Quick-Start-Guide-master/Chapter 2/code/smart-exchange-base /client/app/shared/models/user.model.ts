export class User {
  _id?: string;
  name?:string;
  email?: string;
  role?: string;
}
