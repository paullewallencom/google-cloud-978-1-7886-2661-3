import { FilterThreadPipe } from './filter-thread.pipe';

describe('FilterThreadPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterThreadPipe();
    expect(pipe).toBeTruthy();
  });
});
