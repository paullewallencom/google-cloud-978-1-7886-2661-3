# Cloud Vision API

In the last chapter, we have gone through the high level design of SmartExchange. We have also setup the local development environment and did a code a walkthrough. We have also seen how to deploy the application to Heroku.
In this chapter, we are going to integrate Google Cloud Vision API with SmartExchange.
Topics covered are
* What is Cloud Vision API?
* Explore Cloud Vision API
* Integrate Cloud Vision API with SmartExchange
